;(function ( $ )
{
    $ ( document ).ready ( function ()
    {
        // /**
        //  * Sipariş Listeleme Bölümünde Çalışan Sözleşme Göszteren Js Kodu
        //  */
        //
        // var modalBigContent = new tingle.modal ()
        // $ ( '.sozlesmegosteradmin, .mesafeligosteradmin' ).on ( 'click' , function ()
        // {
        //     var butonid = this.id
        //     modalBigContent.open ()
        //     modalBigContent.setContent ( document.getElementById ( butonid ).innerHTML )
        //
        //     // $('.yazdirbtn').on('click', function () {
        //     //   $('.tingle-modal-box').printThis()
        //     // })
        // } )
    } )
}) ( jQuery )
